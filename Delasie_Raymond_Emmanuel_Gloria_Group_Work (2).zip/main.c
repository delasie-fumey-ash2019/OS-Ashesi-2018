//Group Members: Emmanuel Nimo, Delasie Fumey, Raymond Saaka, Gloria Sekyere
#include <stdio.h>
#include <pthread.h>
#include "concQueue.c"
#include <stdlib.h>


queue_t *queue_c;

void *mythread(void *arg){
    Init_Queue(queue_c);
    int intList[] = {2,4,6,8};
    for(int i = 0; i < 3; i++){
        Enqueue(queue_c, intList[i]);
    }
}

int main(int argc, char const *argv[])
{
    pthread_t p1, p2;
    pthread_create(&p1, NULL, mythread, "A");
    pthread_create(&p2, NULL, mythread, "B");

    pthread_join(p1, NULL);
    pthread_join(p2, NULL);


    printf("main: done with both");
    return 0;

}
