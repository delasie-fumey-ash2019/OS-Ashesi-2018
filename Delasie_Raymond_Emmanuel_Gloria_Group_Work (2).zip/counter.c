//Group Members: Emmanuel Nimo, Delasie Fumey, Raymond Saaka, Gloria Sekyere

#include <stdio.h>
#include <pthread.h>

typedef struct __counter_t{
    int count;
    pthread_mutex_t lock;
} counter_t;

void init(counter_t *c){
    c -> count = 0;
    pthread_mutex_init(&c -> lock, NULL);
}

void increase(counter_t *c){
    pthread_mutex_lock(&c -> lock);
    c -> count++;
    pthread_mutex_unlock(&c -> lock);
}

void decrease(counter_t *c){
    pthread_mutex_lock(&c -> lock);
    c -> count--;
    pthread_mutex_unlock(&c -> lock);
}
